import unittest
from src.preprocessing import clean_text
from src.data_collection import load_dataset
from src.recommendations import recommend_similar_papers

class TestResearchProject(unittest.TestCase):
    def test_clean_text(self):
        result = clean_text("AI Models! https://example.com")
        self.assertIn("ai models", result)
        self.assertNotIn("https", result)

    def test_dataset_has_required_columns(self):
        df = load_dataset()
        self.assertTrue({"title", "abstract", "category", "year"}.issubset(df.columns))
        self.assertGreaterEqual(df["category"].nunique(), 2)

    def test_recommendations(self):
        df = load_dataset()
        results = recommend_similar_papers("machine learning classification", df, top_n=3)
        self.assertLessEqual(len(results), 3)
        self.assertIn("similarity", results.columns)

if __name__ == "__main__":
    unittest.main()
