# Project Report Guide

Include: Abstract; Introduction; Problem Statement; Objectives; Literature Review; System Requirements; Proposed Architecture; Dataset and Preprocessing; TF-IDF and Logistic Regression; Similar-Paper Recommendation; Implementation; Experimental Setup; Results and Discussion; Limitations; Conclusion; Future Scope; References.

Use actual metrics produced by your experiments. Do not present demo-data results as real-world performance.
