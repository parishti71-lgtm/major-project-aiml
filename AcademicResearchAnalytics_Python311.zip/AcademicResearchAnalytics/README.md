# Academic Research Analytics and Paper Classification System

A Python 3.11 / Streamlit educational project that classifies research-paper text, extracts selectable text from PDFs, recommends similar papers, and summarizes the included dataset.

## Features
- TF-IDF + Logistic Regression text classification
- PDF text extraction using pypdf
- Similar-paper recommendations using TF-IDF cosine similarity
- Dataset analytics by category and year
- SQLite classification history
- Model evaluation report and unit tests

## Setup (Windows / VS Code)
```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m src.train_model
streamlit run app.py
```

If PowerShell blocks activation, run:
```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m src.train_model
.\.venv\Scripts\python.exe -m streamlit run app.py
```

## Dataset
On first run, `data/research_papers.csv` is created from a small illustrative demo dataset. It is included only to make the app runnable. Replace it with a larger, properly licensed and labelled dataset for meaningful experiments. Required columns: `title`, `abstract`, `category`, `year`.

## Tests
```powershell
python -m unittest discover -s tests -v
```

## Important limitations
- Scanned/image-only PDFs need OCR, which is not included.
- The demo dataset is tiny and cannot support claims of strong real-world accuracy.
- Similarity scores indicate textual similarity, not scientific quality.
- Do not describe model output as verified truth. Record dataset sources and licenses in your report.
