from pathlib import Path
import json
import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from src.data_collection import load_dataset, DATA_PATH
from src.preprocessing import prepare_dataset

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "models" / "classifier.pkl"
EVALUATION_PATH = ROOT / "reports" / "model_evaluation.csv"
CONFUSION_PATH = ROOT / "reports" / "confusion_matrix.csv"
METRICS_PATH = ROOT / "reports" / "model_metrics.json"

def train_model(dataset_path=DATA_PATH):
    df = prepare_dataset(load_dataset(dataset_path))
    if len(df) < 6 or df["category"].nunique() < 2:
        raise ValueError("Add at least 6 labelled papers across at least 2 categories.")
    X, y = df["text"], df["category"]
    # Stratify only when each category has at least 2 examples and split is feasible.
    counts = y.value_counts()
    stratify = y if counts.min() >= 2 and int(len(df) * 0.25) >= y.nunique() else None
    try:
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.25, random_state=42, stratify=stratify
        )
    except ValueError:
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.25, random_state=42
        )

    model = Pipeline([
        ("tfidf", TfidfVectorizer(ngram_range=(1, 2), max_features=20000, stop_words="english")),
        ("classifier", LogisticRegression(max_iter=2000, class_weight="balanced"))
    ])
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)
    report = classification_report(y_test, predictions, output_dict=True, zero_division=0)
    ROOT.joinpath("models").mkdir(parents=True, exist_ok=True)
    ROOT.joinpath("reports").mkdir(parents=True, exist_ok=True)
    joblib.dump(model, MODEL_PATH)
    pd.DataFrame(report).T.to_csv(EVALUATION_PATH, index=True, index_label="class")
    labels = sorted(y.unique())
    cm = confusion_matrix(y_test, predictions, labels=labels)
    pd.DataFrame(cm, index=labels, columns=labels).to_csv(CONFUSION_PATH, index_label="actual")
    METRICS_PATH.write_text(json.dumps({
        "accuracy": float(accuracy),
        "training_rows": int(len(X_train)),
        "testing_rows": int(len(X_test)),
        "categories": labels,
        "note": "Metrics are from a small starter/demo dataset unless replaced with a larger real dataset."
    }, indent=2), encoding="utf-8")
    return model, {"accuracy": float(accuracy), "training_rows": len(X_train), "testing_rows": len(X_test), "report": report}

if __name__ == "__main__":
    model, result = train_model()
    print(f"Model saved to: {MODEL_PATH}")
    print(f"Test accuracy: {result['accuracy']:.3f}")
    print(f"Evaluation report saved to: {EVALUATION_PATH}")
