from pathlib import Path
import joblib
from src.preprocessing import clean_text

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "models" / "classifier.pkl"

def load_model():
    if not MODEL_PATH.exists():
        from src.train_model import train_model
        train_model()
    return joblib.load(MODEL_PATH)

def predict_category(text, model=None):
    if not str(text).strip():
        raise ValueError("Please provide a paper title, abstract, or PDF text.")
    model = model or load_model()
    cleaned = clean_text(text)
    prediction = str(model.predict([cleaned])[0])
    probabilities = {}
    if hasattr(model, "predict_proba"):
        probs = model.predict_proba([cleaned])[0]
        classes = model.named_steps["classifier"].classes_
        probabilities = {str(label): float(prob) for label, prob in zip(classes, probs)}
    return {"category": prediction, "probabilities": probabilities}
