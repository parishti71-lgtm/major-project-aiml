from io import BytesIO
from pypdf import PdfReader

def extract_pdf_text(file_or_path):
    """Extract selectable text from a PDF file upload or file path."""
    if hasattr(file_or_path, "read"):
        raw = file_or_path.read()
        if hasattr(file_or_path, "seek"):
            file_or_path.seek(0)
        reader = PdfReader(BytesIO(raw))
    else:
        reader = PdfReader(str(file_or_path))
    pages = []
    for page in reader.pages:
        pages.append(page.extract_text() or "")
    text = "\n".join(pages).strip()
    if not text:
        raise ValueError("No selectable text was found. This may be a scanned PDF; OCR is not included in this starter version.")
    return text
