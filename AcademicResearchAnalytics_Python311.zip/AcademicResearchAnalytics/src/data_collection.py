from pathlib import Path
import pandas as pd

DATA_PATH = Path(__file__).resolve().parents[1] / "data" / "research_papers.csv"

# Small DEMO dataset so the project runs immediately.
# Replace/expand it with real, correctly labelled research-paper metadata for research use.
DEMO_PAPERS = [
    ("Machine Learning for Predictive Analytics", "This paper studies supervised machine learning models, feature engineering, classification, regression, and evaluation using training and test datasets.", "Machine Learning", 2022),
    ("Deep Neural Networks for Image Recognition", "Convolutional neural networks learn visual features from image datasets and improve object recognition through deep learning and data augmentation.", "Computer Vision", 2023),
    ("Natural Language Processing with Transformers", "Transformer architectures use attention mechanisms for text classification, language understanding, token representations, and natural language processing.", "Natural Language Processing", 2024),
    ("Sentiment Analysis of Online Reviews", "This study classifies opinions in customer reviews using text preprocessing, sentiment labels, tokenization, and supervised language models.", "Natural Language Processing", 2021),
    ("Object Detection in Autonomous Vehicles", "Computer vision algorithms identify vehicles, pedestrians, and road signs in images and video for perception in autonomous driving.", "Computer Vision", 2024),
    ("Comparing Classification Algorithms", "Logistic regression, support vector machines, and random forests are compared using precision, recall, accuracy, and F1 score.", "Machine Learning", 2020),
    ("Medical Image Segmentation Using CNNs", "Convolutional neural networks segment regions in medical images and support computer-assisted analysis of radiology scans.", "Computer Vision", 2022),
    ("Text Summarization with Language Models", "Automatic summarization generates concise representations of documents using attention, encoder-decoder models, and natural language processing.", "Natural Language Processing", 2023),
    ("Clustering Customer Behaviour", "Unsupervised learning and clustering group customers by behavioural features, purchase patterns, and similarity measures.", "Machine Learning", 2021),
    ("Facial Expression Recognition", "Image preprocessing and convolutional neural networks classify facial expressions from labelled images and visual patterns.", "Computer Vision", 2020),
    ("Question Answering Systems", "Natural language understanding and transformer-based models retrieve answers from passages and evaluate semantic relevance.", "Natural Language Processing", 2022),
    ("Anomaly Detection in Data Streams", "Machine learning models detect unusual patterns in numerical data streams using classification and unsupervised anomaly detection.", "Machine Learning", 2024),
    ("Satellite Image Land Cover Classification", "Computer vision techniques classify satellite imagery into land cover classes using image features and deep neural networks.", "Computer Vision", 2021),
    ("Named Entity Recognition for Scientific Text", "Natural language processing identifies people, organizations, methods, and scientific terms in research documents.", "Natural Language Processing", 2020),
    ("Feature Selection for Predictive Models", "Feature selection reduces dimensionality and helps machine learning models generalize while maintaining predictive performance.", "Machine Learning", 2023),
]
COLUMNS = ["title", "abstract", "category", "year"]

def ensure_dataset(path=DATA_PATH):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        pd.DataFrame(DEMO_PAPERS, columns=COLUMNS).to_csv(path, index=False)
    return path

def load_dataset(path=DATA_PATH):
    ensure_dataset(path)
    df = pd.read_csv(path)
    required = set(COLUMNS)
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Dataset is missing required columns: {', '.join(sorted(missing))}")
    df = df.dropna(subset=["title", "abstract", "category"]).copy()
    df["title"] = df["title"].astype(str).str.strip()
    df["abstract"] = df["abstract"].astype(str).str.strip()
    df["category"] = df["category"].astype(str).str.strip()
    df["year"] = pd.to_numeric(df["year"], errors="coerce")
    df = df[(df["title"] != "") & (df["abstract"] != "") & (df["category"] != "")]
    return df.reset_index(drop=True)
