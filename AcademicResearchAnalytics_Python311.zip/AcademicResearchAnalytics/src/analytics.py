import pandas as pd

def category_counts(df):
    if df.empty or "category" not in df:
        return pd.DataFrame(columns=["category", "papers"])
    return df["category"].value_counts().rename_axis("category").reset_index(name="papers")

def yearly_trends(df):
    if df.empty or "year" not in df:
        return pd.DataFrame(columns=["year", "papers"])
    data = df.copy()
    data["year"] = pd.to_numeric(data["year"], errors="coerce")
    return data.dropna(subset=["year"]).groupby("year").size().reset_index(name="papers").sort_values("year")
