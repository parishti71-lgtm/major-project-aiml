import re
import pandas as pd

def clean_text(text):
    """Lightweight text cleaning while preserving meaningful words and numbers."""
    text = str(text or "").lower()
    text = re.sub(r"https?://\S+|www\.\S+", " ", text)
    text = re.sub(r"[^a-z0-9\s\-]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

def prepare_dataset(df):
    df = df.copy()
    df["title"] = df["title"].fillna("").astype(str)
    df["abstract"] = df["abstract"].fillna("").astype(str)
    df["category"] = df["category"].fillna("").astype(str).str.strip()
    df["text"] = (df["title"] + " " + df["abstract"]).map(clean_text)
    return df[(df["text"] != "") & (df["category"] != "")]
