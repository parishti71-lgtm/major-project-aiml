from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from src.preprocessing import prepare_dataset

def recommend_similar_papers(query, df, top_n=5):
    """Return the most textually similar dataset records for a query."""
    prepared = prepare_dataset(df)
    if prepared.empty or not str(query).strip():
        return prepared.head(0)
    documents = prepared["text"].tolist() if "text" in prepared else (
        prepared["title"].astype(str) + " " + prepared["abstract"].astype(str)
    ).tolist()
    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
    matrix = vectorizer.fit_transform(documents + [str(query)])
    scores = cosine_similarity(matrix[-1], matrix[:-1]).ravel()
    result = prepared.copy()
    result["similarity"] = scores
    result = result.sort_values("similarity", ascending=False)
    return result.head(top_n).drop(columns=["text"], errors="ignore")
