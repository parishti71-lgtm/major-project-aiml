from pathlib import Path
import sqlite3
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt

from src.data_collection import load_dataset, ensure_dataset, DATA_PATH
from src.train_model import train_model, MODEL_PATH
from src.paper_classifier import predict_category
from src.pdf_extractor import extract_pdf_text
from src.recommendations import recommend_similar_papers
from src.analytics import category_counts, yearly_trends

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "database" / "research.db"

st.set_page_config(page_title="Academic Research Analytics", page_icon="📚", layout="wide")

def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(DB_PATH) as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS analyses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT,
                predicted_category TEXT,
                text_preview TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)

def save_analysis(filename, category, text):
    with sqlite3.connect(DB_PATH) as con:
        con.execute(
            "INSERT INTO analyses(filename, predicted_category, text_preview) VALUES (?, ?, ?)",
            (filename, category, text[:500])
        )

@st.cache_data
def get_data():
    return load_dataset()

init_db()
ensure_dataset()

st.title("📚 Academic Research Analytics & Paper Classification")
st.caption("A B.Tech CSE (AI & ML) project for research-paper classification, discovery, and analytics.")

with st.sidebar:
    st.header("Navigation")
    page = st.radio("Choose a page", [
        "Dashboard", "Classify a Paper", "Find Similar Papers", "Dataset", "Model Evaluation"
    ])
    st.divider()
    st.caption("Starter dataset contains illustrative demo records. Replace it with a larger, verified dataset before making research claims.")

try:
    df = get_data()
except Exception as exc:
    st.error(f"Could not load dataset: {exc}")
    st.stop()

if page == "Dashboard":
    st.subheader("Research overview")
    c1, c2, c3 = st.columns(3)
    c1.metric("Papers in dataset", len(df))
    c2.metric("Research categories", df["category"].nunique())
    c3.metric("Publication years", int(df["year"].dropna().nunique()))
    left, right = st.columns(2)
    with left:
        st.markdown("#### Papers by category")
        counts = category_counts(df)
        if not counts.empty:
            fig, ax = plt.subplots()
            ax.bar(counts["category"], counts["papers"])
            ax.set_ylabel("Number of papers")
            ax.tick_params(axis="x", rotation=30)
            fig.tight_layout()
            st.pyplot(fig)
            plt.close(fig)
    with right:
        st.markdown("#### Publications by year")
        trends = yearly_trends(df)
        if not trends.empty:
            fig, ax = plt.subplots()
            ax.plot(trends["year"], trends["papers"], marker="o")
            ax.set_xlabel("Year")
            ax.set_ylabel("Number of papers")
            fig.tight_layout()
            st.pyplot(fig)
            plt.close(fig)
    st.info("Charts summarize the current dataset, not the entire global research literature.")

elif page == "Classify a Paper":
    st.subheader("Classify a research paper")
    mode = st.radio("Input type", ["Paste text", "Upload PDF"], horizontal=True)
    paper_text, filename = "", "pasted_text"
    if mode == "Paste text":
        title = st.text_input("Paper title")
        abstract = st.text_area("Abstract or paper text", height=220)
        paper_text = f"{title}\n{abstract}".strip()
    else:
        uploaded = st.file_uploader("Upload a text-based PDF", type=["pdf"])
        if uploaded:
            filename = uploaded.name
            try:
                paper_text = extract_pdf_text(uploaded)
                st.text_area("Extracted text preview", paper_text[:3000], height=180, disabled=True)
            except Exception as exc:
                st.error(str(exc))
    if st.button("Classify paper", type="primary"):
        if len(paper_text.strip()) < 20:
            st.warning("Please enter a longer title/abstract or upload a readable PDF.")
        else:
            try:
                with st.spinner("Loading model and classifying..."):
                    result = predict_category(paper_text)
                st.success(f"Predicted research category: **{result['category']}**")
                if result["probabilities"]:
                    st.markdown("#### Model scores (not guaranteed to be calibrated confidence)")
                    scores = pd.DataFrame({
                        "Category": list(result["probabilities"].keys()),
                        "Score": list(result["probabilities"].values())
                    }).sort_values("Score", ascending=False)
                    st.bar_chart(scores.set_index("Category"))
                save_analysis(filename, result["category"], paper_text)
                st.caption("This is a model prediction, not a verified assessment of the paper.")
            except Exception as exc:
                st.error(f"Classification failed: {exc}")
                st.info("Check that the dataset has at least two categories and the model can be trained.")

elif page == "Find Similar Papers":
    st.subheader("Find related research")
    query = st.text_area("Enter a title, abstract, or keywords", height=140)
    top_n = st.slider("Number of recommendations", 1, 10, 5)
    if st.button("Find similar papers", type="primary"):
        if not query.strip():
            st.warning("Enter a search query first.")
        else:
            results = recommend_similar_papers(query, df, top_n)
            if results.empty:
                st.info("No recommendations available.")
            else:
                for _, row in results.iterrows():
                    with st.container(border=True):
                        st.markdown(f"**{row['title']}**")
                        st.caption(f"Category: {row['category']} | Year: {row['year']}")
                        st.write(row["abstract"])
                        st.write(f"Text similarity: {row['similarity']:.3f}")

elif page == "Dataset":
    st.subheader("Research-paper dataset")
    st.write("Required columns: title, abstract, category, year.")
    st.dataframe(df, use_container_width=True)
    st.download_button("Download dataset CSV", df.to_csv(index=False).encode("utf-8"),
                       file_name="research_papers.csv", mime="text/csv")
    uploaded_csv = st.file_uploader("Optionally replace dataset with your own CSV", type=["csv"])
    if uploaded_csv and st.button("Validate and save uploaded dataset"):
        try:
            candidate = pd.read_csv(uploaded_csv)
            required = {"title", "abstract", "category", "year"}
            if not required.issubset(candidate.columns):
                st.error(f"CSV must contain columns: {', '.join(sorted(required))}")
            elif candidate.dropna(subset=["title", "abstract", "category"]).shape[0] < 6:
                st.error("Please provide at least 6 rows with titles, abstracts, and categories.")
            else:
                candidate.to_csv(DATA_PATH, index=False)
                get_data.clear()
                st.success("Dataset saved. Retrain the model from the Model Evaluation page.")
                st.rerun()
        except Exception as exc:
            st.error(f"Could not read CSV: {exc}")

elif page == "Model Evaluation":
    st.subheader("Train and evaluate the classifier")
    st.write("The training script uses a TF-IDF + Logistic Regression pipeline and holds out test data.")
    if st.button("Train / retrain model", type="primary"):
        try:
            with st.spinner("Training model..."):
                _, result = train_model()
            st.success(f"Training completed. Model saved at `{MODEL_PATH.relative_to(ROOT)}`.")
            st.metric("Test accuracy", f"{result['accuracy']:.1%}")
            st.write(f"Training rows: {result['training_rows']} | Testing rows: {result['testing_rows']}")
            st.dataframe(pd.DataFrame(result["report"]).T, use_container_width=True)
            st.warning("A small demo dataset cannot establish real-world performance. Use a larger, representative, labelled dataset and avoid duplicate or overlapping papers across train/test sets.")
        except Exception as exc:
            st.error(f"Training failed: {exc}")
    evaluation_path = ROOT / "reports" / "model_evaluation.csv"
    if evaluation_path.exists():
        st.markdown("#### Latest saved evaluation report")
        st.dataframe(pd.read_csv(evaluation_path), use_container_width=True)
    with sqlite3.connect(DB_PATH) as con:
        history = pd.read_sql_query("SELECT id, filename, predicted_category, created_at FROM analyses ORDER BY id DESC LIMIT 100", con)
    st.markdown("#### Recent classification history")
    st.dataframe(history, use_container_width=True)

st.divider()
st.caption("Academic Research Analytics — educational starter project. Validate data quality, model performance, and paper rights before academic or production use.")
